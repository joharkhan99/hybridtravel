<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>
    <?php echo $__env->yieldContent("title", "Hybrid Travel - Admin"); ?>
  </title>
  <?php echo $__env->make("admin.components.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body id="body">
  <?php echo $__env->make("admin.components.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent("content"); ?>
  <?php echo $__env->make("admin.components.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make("admin.components.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH E:\fever\travel agency\hybridtravel\resources\views/layouts/admin.blade.php ENDPATH**/ ?>